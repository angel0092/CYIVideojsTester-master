"use strict";

window.addEventListener("DOMContentLoaded", function(event) {
	document.getElementById("logs").style.height = "800px";
});
